#ifndef MAIN_H
#define MAIN_H

/**
 *  Starta o algoritmo, recebe o arquivo de cidades como argumento
 */
void startTP2(char *citiesFile);

#endif